//
//  ABFriendViewController.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 14.07.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import "ABFriendViewController.h"
#import "ABServerManager.h"
#import "UIImageView+AFNetworking.h"
#import "ABSubscriptionsTableViewController.h"
#import "ABFollowersViewController.h"
#import "ABWallViewController.h"
#import "ABGroupViewController.h"


@implementation ABFriendViewController



-(void) getFriendInfo:(NSString*) userid {
    
    [[ABServerManager sharedManager] requestUserInfo:[userid intValue]
                                           onSuccess:^(NSDictionary* user) {
                                               
                                               self.userid = userid;
                                               self.nameLabel.text = user[@"first_name"];
                                               self.lastnameLabel.text = user[@"last_name"];
                                               self.onlineLabel.text = [user[@"online"] intValue] ? @"Online" : @"Offline" ;
                                               
                                               NSURL* imageUrl = [NSURL URLWithString:user[@"photo_100"]];
                                               NSURLRequest* request = [NSURLRequest requestWithURL:imageUrl];

                                               self.photo.image = nil;
                                               
                                               __weak ABFriendViewController* weakSelf = self;
                                               
                                               [self.photo setImageWithURLRequest:request placeholderImage:nil success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
                                                   
                                                    weakSelf.photo.image = image;
                                                   [weakSelf.photo setNeedsLayout];
                                                   
                                               } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
                                                   NSLog(@"error - %@", [error  localizedDescription]);
                                               }];
                                                                                              
                                               
                                              // [self.tableView reloadData];
                                
                                           }
                                           onFailure:^(NSError *error, NSInteger statusCode) {
        
                                           }];
    
}

- (IBAction)getSubscriptions:(id)sender {
    
    ABSubscriptionsTableViewController* stvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ABSubscriptionsTableViewController"];
    [stvc getSubscriptions:[self.userid intValue]];
    [self.navigationController pushViewController:stvc animated:YES];
}



- (IBAction)getFollowers:(id)sender {
    
    ABFollowersViewController* ftvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ABFollowersViewController"];
    [ftvc getFollowers:[self.userid intValue]];
    [self.navigationController pushViewController:ftvc animated:YES];
}



- (IBAction)getWall:(id)sender {
    
    ABWallViewController* wvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ABWallViewController"];
    [wvc getPostsFromWall:[self.userid intValue]];
    wvc.ownerImage = self.userImage;
    [self.navigationController pushViewController:wvc animated:NO];
}



- (IBAction)getGroups:(id)sender {
    
    ABGroupViewController* gvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ABGroupViewController"];
    [gvc getGroups: [self.userid intValue]];
    [self.navigationController pushViewController:gvc animated:NO];
}







#pragma mark - Table view data source



@end
