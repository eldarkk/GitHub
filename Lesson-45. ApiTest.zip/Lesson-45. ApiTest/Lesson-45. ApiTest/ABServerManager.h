//
//  ABServerManager.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 08.07.17.
//  Copyright © 2017 Eldar. All rights reserved.
//  Application ID	6464838

#import <Foundation/Foundation.h>
#import "ABAccessToken.h"
@class ABUser;

typedef void (^LoginBlock)(NSString*);


@interface ABServerManager : NSObject


@property (strong, nonatomic) ABAccessToken* token;




+(ABServerManager*) sharedManager;

- (void) authorizeUser: (LoginBlock) block;

-(void) requestFriendsOffset:(NSInteger) offset
                       count:(NSInteger) count
                   onSuccess:(void(^)(NSArray* friends)) error
                   onFailure:(void(^)(NSError* error, NSInteger statusCode)) failure;

- (void) requestUserInfo: (NSInteger) userId
               onSuccess:(void(^)(NSDictionary* user)) error
               onFailure:(void(^)(NSError* error, NSInteger statusCode)) failure;

- (void) getSubscriptions : (NSInteger) userId
                    offset: (NSInteger) offset
                     count: (NSInteger) count
                 onSuccess: (void(^)(NSArray* friends)) success
                 onFailure: (void(^)(NSError* error, NSInteger statusCode)) failure;


- (void) getFollowers : (NSInteger) userId
                offset: (NSInteger) offset
                 count: (NSInteger) count
             onSuccess: (void(^)(NSArray* friends)) success
             onFailure: (void(^)(NSError* error, NSInteger statusCode)) failure;

- (void) getPosts : (NSInteger) userId
            offset: (NSInteger) offset
             count: (NSInteger) count
         onSuccess: (void(^)(NSArray* posts)) success
         onFailure: (void(^)(NSError* error, NSInteger statusCode)) failure;

-(void) getGroups : (NSInteger) userId
            offset: (NSInteger) offset
             count: (NSInteger) count
         onSuccess: (void(^)(NSArray* group)) success
         onFailure: (void(^)(NSError* error, NSInteger statusCode)) failure;



@end
