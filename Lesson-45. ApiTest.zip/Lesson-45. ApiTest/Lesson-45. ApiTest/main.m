//
//  main.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 08.07.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
