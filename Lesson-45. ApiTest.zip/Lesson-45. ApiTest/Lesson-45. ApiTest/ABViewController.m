//
//  ABViewController.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 08.07.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import "ABViewController.h"
#import "ABServerManager.h"
#import "UIImageView+AFNetworking.h"
#import "ABUser.h"
#import "ABFriendViewController.h"

@interface ABViewController ()

@property (strong, nonatomic) NSMutableArray* friendsArray;
@property (assign, nonatomic) BOOL authorized;

@end


@implementation ABViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.authorized = NO;
    
    self.friendsArray = [NSMutableArray array];
    //[self getFriends];

}


- (void) viewDidAppear:(BOOL)animated {
    
    [super viewDidAppear:animated];

    if (!self.authorized) {
        self.authorized = YES;
        [[ABServerManager sharedManager] authorizeUser:^(NSString* userID) {
            
            ABFriendViewController* fvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ABFriendViewController"];
            [fvc getFriendInfo:userID];
            
            [self.navigationController pushViewController:fvc animated:YES];

        }];
    }
}


-(void) getFriends {

    [[ABServerManager sharedManager]
     requestFriendsOffset:[self.friendsArray count]
     count:5
     onSuccess:^(NSArray *friends) {
         
         [self.friendsArray addObjectsFromArray:friends];
         
         NSMutableArray* indexes = [NSMutableArray array];
         
         for (int i = (int)[self.friendsArray count] - (int)[friends count]; i < [self.friendsArray count]; i++) {
             
             NSIndexPath* ip = [NSIndexPath indexPathForRow:i inSection:0];
             [indexes addObject:ip];
         }
         
         [self.tableView beginUpdates];
         [self.tableView insertRowsAtIndexPaths:indexes withRowAnimation:UITableViewRowAnimationFade];
         [self.tableView endUpdates];
     }
     onFailure:^(NSError *error, NSInteger statusCode) {
         NSLog(@"Error - %@", [error localizedDescription]);
     }];

    
}







#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.friendsArray count] +1;
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    }
    
    if (indexPath.row == [self.friendsArray count]) {
        cell.textLabel.text = @"Load more";
        cell.imageView.image = nil;
        cell.detailTextLabel.text = @"";
    } else {
    
        
        ABUser* user = self.friendsArray[indexPath.row];
        
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", user.firstname, user.lastname];
        cell.detailTextLabel.text = user.isOnline ? @"ONLINE" : @"OFFLINE" ;
        
        NSURLRequest* request = [NSURLRequest requestWithURL:user.imageUrl];
        UIImage* image = [UIImage imageNamed:@"default.jpeg"];
        
        __weak UITableViewCell* weakCell = cell;
        
        [cell.imageView setImageWithURLRequest:request placeholderImage:image success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
            
            weakCell.imageView.image = image;
            [weakCell setNeedsLayout];
            
        } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
            
            
        }];
        
        
        //[cell layoutSubviews];
    }
    
    return cell;
}


#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.row == [self.friendsArray count]) {
        [self getFriends];
    } else {
        
        ABUser* user = [self.friendsArray objectAtIndex:indexPath.row];
        
        ABFriendViewController* fvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ABFriendViewController"];
        [fvc getFriendInfo:user.userId];
        
        [self.navigationController pushViewController:fvc animated:YES];
        
        
    }
   
}




@end
