//
//  ABGroupViewController.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 01.05.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABGroupViewController : UITableViewController



- (void) getGroups : (NSInteger) userid;


@end
