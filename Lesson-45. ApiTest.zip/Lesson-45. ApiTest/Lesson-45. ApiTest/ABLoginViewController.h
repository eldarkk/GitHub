//
//  ABLoginViewController.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 29.04.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ABAccessToken.h"

typedef void (^ABTokenBlock) (ABAccessToken* )  ;



@interface ABLoginViewController : UIViewController

@property (strong, nonatomic) UIWebView* webView;


- (id) initWithCompletionBlock: (ABTokenBlock) completion;


@end
