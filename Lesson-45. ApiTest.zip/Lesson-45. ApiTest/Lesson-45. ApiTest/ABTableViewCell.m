//
//  ABTableViewCell.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 09.03.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import "ABTableViewCell.h"

@implementation ABTableViewCell


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
