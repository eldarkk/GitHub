//
//  ABWallViewController.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 11.12.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ABUser.h"

@interface ABWallViewController : UITableViewController

@property (strong, nonatomic) UIImage* ownerImage;

- (void) getPostsFromWall: (NSInteger) userId;


@end
