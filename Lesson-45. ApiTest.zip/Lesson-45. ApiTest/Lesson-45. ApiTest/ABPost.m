//
//  ABPost.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 05.06.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import "ABPost.h"
#import "ABServerManager.h"

@implementation ABPost

- (instancetype)initWithResponse: (NSDictionary*) responce
{
    self = [super init];
    if (self) {
        
        //NSLog(@"POST - %@", responce);
        NSInteger ownerID = [[responce objectForKey:@"from_id"] integerValue];
        
        [[ABServerManager sharedManager] requestUserInfo:ownerID onSuccess:^(NSDictionary *user) {
            //NSLog(@"USER - %@", user);
            self.ownerName = [NSString stringWithFormat:@"%@ %@", [user objectForKey:@"first_name"], [user objectForKey:@"last_name"]];
            //NSLog(@"OWNER NAME - %@", self.ownerName);
            self.ownerImage = [user objectForKey:@"photo_50"];
        } onFailure:^(NSError *error, NSInteger statusCode) {
            if (error) {
                NSLog(@"ERROR - %@", [error description]);
            }
            
        }];
        
        self.postText = [responce objectForKey:@"text"];
        //self.postDate = [[responce objectForKey:@"date"] timeIntervalSince1970];
        self.postImage = [[[responce objectForKey:@"attachment"] objectForKey:@"photo"] objectForKey:@"src_big"];
        self.comments = [[[responce objectForKey:@"comments"] objectForKey:@"count"] integerValue];
        self.likes = [[[responce objectForKey:@"likes"] objectForKey:@"count"] integerValue];
        
  
    }

    return self;
}


@end
