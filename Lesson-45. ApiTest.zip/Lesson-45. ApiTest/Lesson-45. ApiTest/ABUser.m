//
//  ABUser.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 09.07.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import "ABUser.h"

@implementation ABUser



- (ABUser*)initWithResponse:(NSDictionary*) dictionary
{
    self = [super init];
    if (self) {
        
        self.firstname = dictionary[@"first_name"];
        self.lastname = dictionary[@"last_name"];
        self.userId = dictionary[@"user_id"];
        self.isOnline = [dictionary[@"online"] integerValue];
        
        NSURL* url = [NSURL URLWithString:dictionary[@"photo_100"]];
        self.imageUrl = url;
        
    }
    return self;
}


@end
