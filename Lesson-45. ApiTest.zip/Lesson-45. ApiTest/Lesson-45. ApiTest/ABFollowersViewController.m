//
//  ABFollowersViewController.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 10.12.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import "ABFollowersViewController.h"
#import "ABServerManager.h"
#import "UIImageView+AFNetworking.h"


@interface ABFollowersViewController ()

@property (strong, nonatomic) NSMutableArray* followers;

@end

@implementation ABFollowersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.followers = [NSMutableArray array];
    
}


-(void) getFollowers:(NSInteger)userId  {
   
    [[ABServerManager sharedManager] getFollowers:userId offset:0 count:20 onSuccess:^(NSArray* followers) {
    
        [self.followers addObjectsFromArray:followers];
        [self.tableView reloadData];
        
        
    } onFailure:^(NSError *error, NSInteger statusCode) {
        
    }];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.followers count];
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    }
    
    NSDictionary* dict = [self.followers objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@",[dict objectForKey:@"first_name"], [dict objectForKey:@"last_name"]];
    
    NSString* imageUrlString = [dict objectForKey:@"photo_100"];
    NSURL* imageUrl = [NSURL URLWithString: imageUrlString];
    NSURLRequest* request = [NSURLRequest requestWithURL:imageUrl];
    
    UIImage* image = [UIImage imageNamed:@"default.jpeg"];
    
    __weak UITableViewCell* weakCell = cell;
    
    [cell.imageView setImageWithURLRequest:request placeholderImage:image success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
        
        weakCell.imageView.image = image;
        [weakCell setNeedsLayout];
        
    } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
        
        
    }];

    
    return cell;
}


@end






