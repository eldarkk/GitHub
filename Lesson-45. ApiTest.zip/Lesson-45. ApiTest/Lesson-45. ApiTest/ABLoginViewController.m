//
//  ABLoginViewController.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 29.04.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import "ABLoginViewController.h"



@interface ABLoginViewController () <UIWebViewDelegate>

@property (copy, nonatomic) ABTokenBlock tokenBlock;


@end



@implementation ABLoginViewController


- (id) initWithCompletionBlock: (ABTokenBlock) completion {
    
    self = [super init];
    if (self) {
        self.tokenBlock = completion;
        
    }
    return self;
    
    
    
}




- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    CGRect r = self.view.bounds;
    r.origin = CGPointZero;
    
    UIWebView* webView = [[UIWebView alloc] initWithFrame:r];
    self.webView = webView;
    self.webView.delegate = self;
    
    [self.view addSubview:webView];
    
    UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelAction:)];
    
    [self.navigationItem setRightBarButtonItem:item];
    
    NSString* urlString = @"https://oauth.vk.com/authorize?client_id=6464838&display=page&redirect_uri=hello.kz&scope=friends&response_type=token&v=5.52";
    
    NSURL* url = [NSURL URLWithString:urlString];
    
    NSURLRequest* request = [NSURLRequest requestWithURL:url];
    
    [self.webView loadRequest:request];
    
}


-(void) dealloc {
    self.webView.delegate = nil;
}



- (void) cancelAction:(UIBarButtonItem*) item {
    
    if (self.tokenBlock) {
        self.tokenBlock(nil);
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}



// access_token=7cd3f3b152e1325bb873bd2605a25fd89a3774ea9453e65ccd567c240f6d4a71115b49d98eb1fecb34493&expires_in=86400&user_id=485603454

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    //NSLog(@"%@", [request URL]);
    NSString* answer = [[request URL] description];
    
    if ([answer containsString:@"access_token"]) {
        
        ABAccessToken* token = [[ABAccessToken alloc] init];
        
        NSArray* array = [answer componentsSeparatedByString:@"#"];
        
        NSArray* pairs = [[array lastObject] componentsSeparatedByString:@"&"];
        
        NSArray* tokenPair = [[pairs firstObject] componentsSeparatedByString:@"="];
        NSArray* expirePair = [[pairs objectAtIndex:1] componentsSeparatedByString:@"="];
        NSArray* userIDPair = [[pairs lastObject] componentsSeparatedByString:@"="];
        
        token.token = [tokenPair lastObject];
        token.expirationDate = [expirePair lastObject];
        token.userID = [userIDPair lastObject];
        
    
        self.webView.delegate = nil;
        self.webView = nil;
        
        
        if (self.tokenBlock) {
            self.tokenBlock(token);
        }
        
        [self dismissViewControllerAnimated:YES completion:nil];
        
    }
    
    
    
    
    return 1;
    
}


@end
