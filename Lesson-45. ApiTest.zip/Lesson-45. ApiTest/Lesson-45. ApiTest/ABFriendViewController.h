//
//  ABFriendViewController.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 14.07.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ABUser.h"

@interface ABFriendViewController : UITableViewController

@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UILabel *lastnameLabel;
@property (strong, nonatomic) IBOutlet UIImageView *photo;
@property (strong, nonatomic) IBOutlet UILabel *onlineLabel;
@property (strong, nonatomic) NSString* userid;
@property (strong, nonatomic) UIImage* userImage;


-(void) getFriendInfo:(NSString*) userid;
- (IBAction)getFollowers:(id)sender;
- (IBAction)getSubscriptions:(id)sender;
- (IBAction)getWall:(id)sender;
- (IBAction)getGroups:(id)sender;



@end
