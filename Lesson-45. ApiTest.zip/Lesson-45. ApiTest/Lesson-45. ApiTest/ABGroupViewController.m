//
//  ABGroupViewController.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 01.05.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import "ABGroupViewController.h"
#import "ABServerManager.h"
#import "UIImageView+AFNetworking.h"
#import "ABWallViewController.h"

@interface ABGroupViewController ()

@property (strong, nonatomic) NSArray* groups;
@end
@implementation ABGroupViewController


- (void) getGroups : (NSInteger) userid{
    
    [[ABServerManager sharedManager] getGroups:userid
                                        offset:0
                                         count:100
                                     onSuccess:^(NSArray *groups) {
                                      
                                         NSLog(@"ABGroupViewController - %@", groups);
                                         self.groups = groups;
                                         
                                         [self.tableView reloadData];
                                     }
                                     onFailure:^(NSError *error, NSInteger statusCode) {
                                     }];
}



- (void)viewDidLoad {
    [super viewDidLoad];
    self.groups = [NSArray array];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    //return [[self.groups objectAtIndex:0] integerValue];
    return [self.groups count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"Cell"];
    }

    NSDictionary* groupDict = [self.groups objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [groupDict objectForKey:@"name"];
    cell.detailTextLabel.text = [groupDict objectForKey:@"gid"];
    
    NSString* imageUrlString = [groupDict objectForKey:@"photo_100"];
    NSURL* imageUrl = [NSURL URLWithString: imageUrlString];
    NSURLRequest* request = [NSURLRequest requestWithURL:imageUrl];
    
    UIImage* image = [UIImage imageNamed:@"default.jpeg"];
    
    __weak UITableViewCell* weakCell = cell;
    
    [cell.imageView setImageWithURLRequest:request placeholderImage:image
                                   success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull image) {
        
        weakCell.imageView.image = image;
        //[weakCell setNeedsLayout];
        
    } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
    }];

    return cell;
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    

    NSString* gid = [[self.groups objectAtIndex:indexPath.row] objectForKey:@"gid"];
    NSString* userID = [NSString stringWithFormat:@"-%@", gid];
        
    ABWallViewController* wvc = [self.storyboard instantiateViewControllerWithIdentifier:@"ABWallViewController"];
    [wvc getPostsFromWall:[userID intValue]];
    
    
    [self.navigationController pushViewController:wvc animated:NO];

    
}






@end
