//
//  ABServerManager.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 08.07.17.
//  Copyright © 2017 Eldar. All rights reserved.

#import "ABServerManager.h"
#import "AFNetworking.h"
#import "ABUser.h"
#import "ABLoginViewController.h"

@implementation ABServerManager

+(ABServerManager*) sharedManager {
    static ABServerManager* manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[ABServerManager alloc] init];
    });
    return manager;
}




- (void) authorizeUser: (LoginBlock) block{
    
    ABLoginViewController* vc = [[ABLoginViewController alloc] initWithCompletionBlock:^(ABAccessToken* token){
        NSLog(@"EXIT TOKEN - %@, %@ , %@", token.token, token.expirationDate, token.userID);
        
        self.token = token;
        
        block(token.userID);
        
        
    }];

    UINavigationController* nv = [[UINavigationController alloc] initWithRootViewController:vc];
    UIViewController* mvc = [[[UIApplication sharedApplication] windows] firstObject].rootViewController;
    [mvc presentViewController:nv animated:YES completion:nil];
    
    
}

-(void) requestFriendsOffset:(NSInteger) offset
                       count:(NSInteger) count
                   onSuccess:(void(^)(NSArray* friends)) success
                   onFailure:(void(^)(NSError* error, NSInteger statusCode)) failure{
    
    NSString *URLString = @"https://api.vk.com/method/friends.get";
    NSDictionary *parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                @"5.73"     , @"version",
                                @"26955116" ,@"user_id",
                                @"name"    ,@"order",
                                @(offset)   , @"offset",
                                @(count)    , @"count",
                                @"photo_100,online", @"fields",
                                @"nom"      , @"name_case", nil];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    [manager GET:URLString parameters:parameters progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        // NSLog(@"JSON: %@", responseObject);
        
        NSArray* friendsArray = [responseObject objectForKey:@"response"];
        NSMutableArray* objectsArray = [NSMutableArray array];
        
        for (NSDictionary* each in friendsArray) {
            ABUser* user = [[ABUser alloc] initWithResponse:each];
            [objectsArray addObject:user];
        }
        
        
        if (success) {
            success(objectsArray);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        
        if (failure) {
            failure(error, 0);
        }
    }];
}









-(void) requestUserInfo:(NSInteger) userId
              onSuccess:(void (^)(NSDictionary*)) success
              onFailure:(void (^)(NSError *, NSInteger))failure{
    
    NSString* userIds = [NSString stringWithFormat:@"%ld", (long)userId];
    
    NSDictionary* parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                            @"5.73"     , @"version",
                            userIds, @"user_ids",
                            @"photo_50, photo_100, online" , @"fields",
                            @"nom", @"name_case",
                            self.token.token, @"access_token",nil];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:@"https://api.vk.com/method/users.get" parameters:parameters progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        
        NSArray* array = [responseObject objectForKey:@"response"];
        NSDictionary* dict = [array firstObject];
        
        if (success) {
            success(dict);
        }
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        
        if (failure) {
            failure(error, 0);
        }
    }];
    
    
    
}


-(void) getSubscriptions : (NSInteger) userId
                   offset: (NSInteger) offset
                    count: (NSInteger) count
                onSuccess: (void(^)(NSArray* friends)) success
                onFailure: (void(^)(NSError* error, NSInteger statusCode)) failure {

    NSString* userid = [NSString stringWithFormat:@"%ld", (long)userId];
    NSDictionary* parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                @"5.73"     , @"version",
                                userid, @"user_id",
                                @(1), @"extended",
                                @(offset), @"offset",
                                @(count), @"count",
                                @"photo_100", @"fields", nil];

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    [manager GET:@"https://api.vk.com/method/users.getSubscriptions" parameters:parameters progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        

        NSArray* array = [responseObject objectForKey:@"response"];
        
        if (success) {
            success(array);
        }
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        
        if (failure) {
            failure(error, 0);
        }
    }];

}

-(void) getFollowers:(NSInteger)userId
              offset:(NSInteger)offset
               count:(NSInteger)count onSuccess:(void (^)(NSArray *))success
           onFailure:(void (^)(NSError *, NSInteger))failure {
    
    NSString* userid = [NSString stringWithFormat:@"%ld", (long)userId];
    NSDictionary* parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                userid, @"user_id",
                                @(offset), @"offset",
                                @(count), @"count",
                                @"photo_100,online", @"fields",
                                @"nom"      , @"name_case",
                                nil];
    
    
    
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:@"https://api.vk.com/method/users.getFollowers" parameters:parameters progress:nil success:^(NSURLSessionTask *task, id responseObject) {
       
        NSDictionary* dict = [responseObject objectForKey:@"response"];
        NSArray* array = [dict objectForKey:@"items"];
        
        if (success) {
            success(array);
        }
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        if (failure) {
            failure(error, 0);
        }
    }
     
    ];
     
     
    
}

    
//14878b9314878b9314878b93c014e7a

- (void) getPosts : (NSInteger) userId
            offset: (NSInteger) offset
             count: (NSInteger) count
         onSuccess: (void(^)(NSArray* posts)) success
         onFailure: (void(^)(NSError* error, NSInteger statusCode)) failure{
    
    NSDictionary* parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                @"5.73"     , @"version",
                                @(userId), @"owner_id",
                                @(0), @"extended",
                                @(offset), @"offset",
                                @(count), @"count",
                                self.token.token, @"access_token",
                                @"ru", @"lang",
                                nil];
    
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:@"https://api.vk.com/method/wall.get" parameters:parameters progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        
        //NSLog(@"FIRST DICT %@", responseObject);
        
        NSMutableArray* dict = [[responseObject objectForKey:@"response"] mutableCopy];
        [dict removeObjectAtIndex:0];
        
        NSLog(@"COUNT - %lu", (unsigned long)[dict count]);
        
        /*
        for (int i = 0; i < [dict count]; i++) {
            NSLog(@"%@", dict[i]);
        }
        */
        
        if (success) {
            success(dict);
        }

        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        if (failure) {
            failure(error, 0);
        }
    }];

}



-(void) getGroups : (NSInteger) userId
                   offset: (NSInteger) offset
                    count: (NSInteger) count
                onSuccess: (void(^)(NSArray* groups)) success
                onFailure: (void(^)(NSError* error, NSInteger statusCode)) failure {
    
    NSString* userid = [NSString stringWithFormat:@"%ld", (long)userId];
    NSDictionary* parameters = [NSDictionary dictionaryWithObjectsAndKeys:
                                @"5.73"     , @"version",
                                userid, @"user_id",
                                self.token.token, @"access_token",
                                @(1), @"extended",
                                @(offset), @"offset",
                                @(count), @"count",
                                @"photo_100", @"fields", nil];
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    [manager GET:@"https://api.vk.com/method/groups.get" parameters:parameters progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        
        NSMutableArray* array = [NSMutableArray arrayWithArray:  [responseObject objectForKey:@"response"]];
        [array removeObjectAtIndex:0];
        
        if (success) {
            success(array);
        }
        
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
        
        if (failure) {
            failure(error, 0);
        }
    }];
}






@end







