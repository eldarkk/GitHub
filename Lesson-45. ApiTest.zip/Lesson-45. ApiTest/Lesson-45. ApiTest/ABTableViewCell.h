//
//  ABTableViewCell.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 09.03.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *ownerImage;
@property (strong, nonatomic) IBOutlet UILabel *ownerLabel;
@property (strong, nonatomic) IBOutlet UILabel *postText;
@property (strong, nonatomic) IBOutlet UIImageView *postImage;

@property (strong, nonatomic) IBOutlet UILabel *likesLabel;
@property (strong, nonatomic) IBOutlet UILabel *commentLabel;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *postImageHeight;

@end
