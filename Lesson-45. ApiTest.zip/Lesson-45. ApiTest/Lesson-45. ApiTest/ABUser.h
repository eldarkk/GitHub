//
//  ABUser.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 09.07.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ABUser : NSObject

@property (strong, nonatomic) NSString* firstname;
@property (strong, nonatomic) NSString* lastname;
@property (strong, nonatomic) NSURL* imageUrl;
@property (strong, nonatomic) NSString* userId;
@property (assign, nonatomic) NSInteger isOnline;


- (ABUser*)initWithResponse:(NSDictionary*) dictionary;

@end
