//
//  ABSubscriptionsTableViewController.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 13.10.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABSubscriptionsTableViewController : UITableViewController


- (void) getSubscriptions : (NSInteger) userid ;


@end
