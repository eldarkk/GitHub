//
//  ABPost.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 05.06.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ABPost : NSObject

@property (strong, nonatomic) NSString* ownerName;
@property (strong, nonatomic) NSString* ownerImage;;
@property (strong, nonatomic) NSString* postText;
@property (strong, nonatomic) NSString* postImage;
@property (strong, nonatomic) NSString* postDate;
@property (assign, nonatomic) NSInteger comments;
@property (assign, nonatomic) NSInteger likes;

- (instancetype)initWithResponse: (NSDictionary*) responce;

@end
