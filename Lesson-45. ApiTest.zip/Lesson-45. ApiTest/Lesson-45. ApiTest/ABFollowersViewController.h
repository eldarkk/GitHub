//
//  ABFollowersViewController.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 10.12.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABFollowersViewController : UITableViewController



-(void) getFollowers:(NSInteger) userId;

@end
