//
//  ABWallViewController.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 11.12.17.
//  Copyright © 2017 Eldar. All rights reserved.
//

#import "ABWallViewController.h"
#import "ABServerManager.h"
#import "ABTableViewCell.h"
#import "UIImageView+AFNetworking.h"
#import "ABPost.h"

@interface ABWallViewController ()
@property (strong, nonatomic) NSMutableArray* posts;
@end


@implementation ABWallViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.posts = [NSMutableArray array];
    
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = UITableViewAutomaticDimension; // set to whatever your "average" cell height is
}


- (void) getPostsFromWall:(NSInteger) userId {
    
    [[ABServerManager sharedManager] getPosts:userId offset:[self.posts count] count:5 onSuccess:^(NSArray* posts) {
        
        [self.posts addObjectsFromArray:posts];
        
        NSMutableArray* indexPaths = [NSMutableArray array];
        
        for (NSInteger i = [self.posts count] - [posts count]; i < [self.posts count]; i++) {
            NSIndexPath* indexPath = [NSIndexPath indexPathForRow:i inSection:0];
            [indexPaths addObject:indexPath];
        }
        
        [self.tableView beginUpdates];
        [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:(UITableViewRowAnimationRight)];
        [self.tableView endUpdates];

    } onFailure:^(NSError *error, NSInteger statusCode) {
    }];
}



#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return [self.posts count] + 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == [self.posts count]) {

        static NSString* identifier = @"Cell";
        
        UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        if (!cell) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
            cell.textLabel.text = @"LOAD MORE!";
            cell.detailTextLabel.text = @"";
            cell.imageView.image = nil;
        
        return cell;
        
        }
    
    if ((indexPath.row != [self.posts count]) && ([self.posts count] > 0)) {
        
        ABTableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"CustomCell" forIndexPath:indexPath];
        
        
       //dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
           
       ABPost* post = [[ABPost alloc] initWithResponse:[self.posts objectAtIndex:indexPath.row]];
           
           //dispatch_async(dispatch_get_main_queue(), ^{
               
       cell.ownerLabel.text = post.ownerName;
       cell.postText.text = post.postText;
       //cell.postText.lineBreakMode = NSLineBreakByWordWrapping;
       cell.postText.numberOfLines = 0;
        
        if (post.postImage) {
        
        NSURL* imageUrl = [NSURL URLWithString:post.postImage];
        NSURLRequest* imageRequest = [NSURLRequest requestWithURL:imageUrl];
        
        __weak ABTableViewCell* weakCell = cell;
        
        [cell.postImage setImageWithURLRequest:imageRequest placeholderImage:nil
                                       success:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, UIImage * _Nonnull  image) {

                                           weakCell.postImage.image = image;
                                           weakCell.postImage.contentMode = UIViewContentModeScaleAspectFit;
                                           
                                           if (!image) {
                                               weakCell.postImageHeight.constant = 0.f;
                                           }
                                           
                                           NSLog(@"SIZE - %.f , %.f", image.size.height, image.size.width);


                                       } failure:^(NSURLRequest * _Nonnull request, NSHTTPURLResponse * _Nullable response, NSError * _Nonnull error) {
                                       }];


        return cell;
        }
    }

    return nil;
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == [self.posts count]) {
        [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
        
        [self getPostsFromWall:[@"-58860049" intValue]];
    } else {
        [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    }
    
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

        return UITableViewAutomaticDimension;
}



@end
