//
//  AccessToken.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 29.04.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AccessToken : NSObject

@property (strong, nonatomic) NSString* token;
@property (strong, nonatomic) NSDate* expirationDate;

@end
