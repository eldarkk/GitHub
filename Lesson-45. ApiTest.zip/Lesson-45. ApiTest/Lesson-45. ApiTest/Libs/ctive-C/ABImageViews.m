//
//  ABImageViews.m
//  Lesson-45. ApiTest
//
//  Created by Eldar on 10.06.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import "ABImageViews.h"

@implementation ABImageViews

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
