//
//  ABImageView.h
//  Lesson-45. ApiTest
//
//  Created by Eldar on 25.06.18.
//  Copyright © 2018 Eldar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ABImageView : UIImageView

@end
